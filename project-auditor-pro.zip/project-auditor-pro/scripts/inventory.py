#!/usr/bin/env python3
"""Read-only repository inventory helper. Does not open file contents or modify files."""
from pathlib import Path
import argparse
import json

DEFAULT_EXCLUDES = {
    ".git", ".hg", ".svn", "node_modules", "vendor", ".venv", "venv",
    "__pycache__", ".mypy_cache", ".pytest_cache", ".next", "dist", "build",
    "coverage", ".turbo", ".cache", "target"
}

def main():
    parser = argparse.ArgumentParser(description="Create a read-only project file inventory.")
    parser.add_argument("root", nargs="?", default=".", help="Repository root")
    parser.add_argument("--include-generated", action="store_true",
                        help="Include common generated/build directories")
    parser.add_argument("--json", action="store_true", help="Emit JSON")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    if not root.is_dir():
        parser.error(f"Not a directory: {root}")

    excludes = set() if args.include_generated else DEFAULT_EXCLUDES
    records = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if any(part in excludes for part in rel.parts):
            continue
        try:
            size = path.stat().st_size
        except OSError:
            size = None
        records.append({
            "path": rel.as_posix(),
            "suffix": path.suffix.lower(),
            "bytes": size,
        })

    if args.json:
        print(json.dumps({"root": str(root), "count": len(records), "files": records}, indent=2))
    else:
        print(f"Root: {root}\nFiles: {len(records)}")
        for item in records:
            size = "?" if item["bytes"] is None else str(item["bytes"])
            print(f'{item["path"]}\t{size} bytes')

if __name__ == "__main__":
    main()
